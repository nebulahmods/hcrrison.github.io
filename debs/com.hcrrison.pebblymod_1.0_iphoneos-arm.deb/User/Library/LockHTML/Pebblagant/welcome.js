var welcomeID = document.getElementById("welcome");

welcome.innerText = "ssss";